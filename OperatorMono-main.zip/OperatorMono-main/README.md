# OperatorMono
The Operator Mono Font With Custom Ligatures
